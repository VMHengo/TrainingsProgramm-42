Installation:
Man muss einen Ordner auf dem Flash anlegen der "music" heißt und darin dann infiltration.wav ablegen.
Dies geht am einfachsten indem man einmal CircuitPython auf den PyBadge installiert (geht wie ein Bootloader Update).
Der dann erkannte USB-Stick ist direkt der korrekt formatierte Flash auf dem man arbeiten kann.

Gameplay:
Man muss in dem Moment wo der Kreis am kleinsten ist in die Richtung drücken aus der der Kreis kleiner wurde.
Alternativ kann man auch einfach A drücken. Damit wird die Richtung ignoriert.

Die Lizenz des Liedes ist CC BY-SA 3.0:
- Attribution: Infiltration from PragonX9 available at NEWGROUNDS (https://www.newgrounds.com/audio/listen/157014)
- Modifications: Stereo to mono mixdown and sampling rate reduction to 8kHz
